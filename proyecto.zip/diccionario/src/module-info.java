/**
 * 
 */
/**
 * 
 */
module diccionario {
	requires java.desktop;
}