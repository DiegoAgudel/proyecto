package igu;



import logica.Diccionario;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
public class InterfazGrafica {
    private Diccionario diccionario;

    // Constructor
    public InterfazGrafica(Diccionario diccionario) {
        this.diccionario = diccionario;

        // Crear la ventana
        JFrame frame = new JFrame("Diccionario Multilingüe");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 500);

        // Crear el panel
        JPanel panel = new JPanel();
        panel.setLayout(null);

        // Crear etiquetas y campos de texto para ingresar palabras
        JLabel labelEspañol = new JLabel("Español:");
        labelEspañol.setBounds(20, 20, 100, 25);
        panel.add(labelEspañol);
        JTextField espanolField = new JTextField();
        espanolField.setBounds(120, 20, 150, 25);
        panel.add(espanolField);

        JLabel labelIngles = new JLabel("Inglés:");
        labelIngles.setBounds(20, 60, 100, 25);
        panel.add(labelIngles);
        JTextField inglesField = new JTextField();
        inglesField.setBounds(120, 60, 150, 25);
        panel.add(inglesField);

        JLabel labelFrances = new JLabel("Francés:");
        labelFrances.setBounds(20, 100, 100, 25);
        panel.add(labelFrances);
        JTextField francesField = new JTextField();
        francesField.setBounds(120, 100, 150, 25);
        panel.add(francesField);

        JLabel labelPortugues = new JLabel("Portugués:");
        labelPortugues.setBounds(20, 140, 100, 25);
        panel.add(labelPortugues);
        JTextField portuguesField = new JTextField();
        portuguesField.setBounds(120, 140, 150, 25);
        panel.add(portuguesField);

        // Crear botón para agregar palabra
        JButton agregarButton = new JButton("Agregar Palabra");
        agregarButton.setBounds(20, 180, 200, 30);
        panel.add(agregarButton);

        // Crear campo de texto para eliminar palabra
        JLabel eliminarLabel = new JLabel("Eliminar Palabra:");
        eliminarLabel.setBounds(20, 220, 100, 25);
        panel.add(eliminarLabel);
        JTextField eliminarField = new JTextField();
        eliminarField.setBounds(120, 220, 150, 25);
        panel.add(eliminarField);

        // Crear botón para eliminar palabra
        JButton eliminarButton = new JButton("Eliminar");
        eliminarButton.setBounds(230, 220, 100, 30);
        panel.add(eliminarButton);

        // Crear campo de texto para búsqueda
        JLabel buscarLabel = new JLabel("Buscar Palabra:");
        buscarLabel.setBounds(20, 260, 100, 25);
        panel.add(buscarLabel);
        JTextField buscarField = new JTextField();
        buscarField.setBounds(120, 260, 150, 25);
        panel.add(buscarField);

        // Crear botón para buscar palabra
        JButton buscarButton = new JButton("Buscar");
        buscarButton.setBounds(20, 300, 200, 30);
        panel.add(buscarButton);

        // Crear área de texto para mostrar resultados
        JTextArea resultadoArea = new JTextArea();
        resultadoArea.setBounds(20, 340, 440, 100);
        resultadoArea.setEditable(false);
        panel.add(resultadoArea);

        // Acción para el botón de agregar palabra
        agregarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String espanol = espanolField.getText().trim();
                String ingles = inglesField.getText().trim();
                String frances = francesField.getText().trim();
                String portugues = portuguesField.getText().trim();
                if (!espanol.isEmpty() && !ingles.isEmpty() && !frances.isEmpty() && !portugues.isEmpty()) {
                    diccionario.agregarPalabra(espanol, ingles, frances, portugues);
                    JOptionPane.showMessageDialog(frame, "Palabra agregada con éxito.");
                    espanolField.setText("");
                    inglesField.setText("");
                    francesField.setText("");
                    portuguesField.setText("");
                } else {
                    JOptionPane.showMessageDialog(frame, "Por favor, completa todos los campos.");
                }
            }
        });

        // Acción para el botón de eliminar palabra
        eliminarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String palabra = eliminarField.getText().trim();
                if (!palabra.isEmpty()) {
                    diccionario.eliminarPalabra(palabra);
                    JOptionPane.showMessageDialog(frame, "Palabra eliminada con éxito.");
                    eliminarField.setText("");
                } else {
                    JOptionPane.showMessageDialog(frame, "Por favor, ingresa una palabra para eliminar.");
                }
            }
        });

        // Acción para el botón de buscar palabra
        buscarButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String palabra = buscarField.getText().trim();
                if (!palabra.isEmpty()) {
                    String resultado = diccionario.buscarPalabra(palabra);
                    resultadoArea.setText(resultado);
                } else {
                    JOptionPane.showMessageDialog(frame, "Por favor, ingresa una palabra para buscar.");
                }
            }
        });

        // Añadir el panel a la ventana y hacerla visible
        frame.add(panel);
        frame.setVisible(true);
    }
}