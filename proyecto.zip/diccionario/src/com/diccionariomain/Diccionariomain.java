package com.diccionariomain;
import igu.InterfazGrafica;
import percistencia.GestorArchivo;
import logica.Diccionario;

public class Diccionariomain {

    public static void main(String[] args) {
        // Crear el diccionario
        Diccionario diccionario = new Diccionario();

        // Cargar el diccionario desde el archivo
        try {
            GestorArchivo.cargarDiccionario(diccionario);
        } catch (Exception e) {
            System.out.println("Error al cargar el diccionario: " + e.getMessage());
        }

        // Mostrar la interfaz gráfica
        new InterfazGrafica(diccionario);
    }
}
