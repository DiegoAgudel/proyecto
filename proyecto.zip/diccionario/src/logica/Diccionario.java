package logica;

import java.util.ArrayList;
import java.util.List;
public class Diccionario {
    // Lista de palabras en los 4 idiomas
    private List<String> palabrasEspañol;
    private List<String> palabrasIngles;
    private List<String> palabrasFrances;
    private List<String> palabrasPortugues;

    // Constructor
    public Diccionario() {
        palabrasEspañol = new ArrayList<>();
        palabrasIngles = new ArrayList<>();
        palabrasFrances = new ArrayList<>();
        palabrasPortugues = new ArrayList<>();
    }

    // Método para agregar una palabra en los 4 idiomas
    public void agregarPalabra(String palabraEspañol, String palabraIngles, String palabraFrances, String palabraPortugues) {
        if (!palabrasEspañol.contains(palabraEspañol)) {
            palabrasEspañol.add(palabraEspañol);
            palabrasIngles.add(palabraIngles);
            palabrasFrances.add(palabraFrances);
            palabrasPortugues.add(palabraPortugues);
        }
    }

    // Método para eliminar una palabra en los 4 idiomas
    public void eliminarPalabra(String palabra) {
        int index = palabrasEspañol.indexOf(palabra);
        if (index != -1) {
            palabrasEspañol.remove(index);
            palabrasIngles.remove(index);
            palabrasFrances.remove(index);
            palabrasPortugues.remove(index);
        }
    }

    // Método para buscar una palabra en cualquier idioma
    public String buscarPalabra(String palabra) {
        int indexEsp = palabrasEspañol.indexOf(palabra);
        if (indexEsp != -1) {
            return "Español: " + palabrasEspañol.get(indexEsp) + "\n" +
                   "Inglés: " + palabrasIngles.get(indexEsp) + "\n" +
                   "Francés: " + palabrasFrances.get(indexEsp) + "\n" +
                   "Portugués: " + palabrasPortugues.get(indexEsp);
        }

        int indexIng = palabrasIngles.indexOf(palabra);
        if (indexIng != -1) {
            return "Español: " + palabrasEspañol.get(indexIng) + "\n" +
                   "Inglés: " + palabrasIngles.get(indexIng) + "\n" +
                   "Francés: " + palabrasFrances.get(indexIng) + "\n" +
                   "Portugués: " + palabrasPortugues.get(indexIng);
        }

        int indexFra = palabrasFrances.indexOf(palabra);
        if (indexFra != -1) {
            return "Español: " + palabrasEspañol.get(indexFra) + "\n" +
                   "Inglés: " + palabrasIngles.get(indexFra) + "\n" +
                   "Francés: " + palabrasFrances.get(indexFra) + "\n" +
                   "Portugués: " + palabrasPortugues.get(indexFra);
        }

        int indexPor = palabrasPortugues.indexOf(palabra);
        if (indexPor != -1) {
            return "Español: " + palabrasEspañol.get(indexPor) + "\n" +
                   "Inglés: " + palabrasIngles.get(indexPor) + "\n" +
                   "Francés: " + palabrasFrances.get(indexPor) + "\n" +
                   "Portugués: " + palabrasPortugues.get(indexPor);
        }

        return "Palabra no encontrada en el diccionario.";
    }

    // Obtener todas las palabras del diccionario
    public List<String> getTodasLasPalabras() {
        List<String> todasLasPalabras = new ArrayList<>();
        for (int i = 0; i < palabrasEspañol.size(); i++) {
            todasLasPalabras.add("Español: " + palabrasEspañol.get(i) + " | Inglés: " + palabrasIngles.get(i) +
                                 " | Francés: " + palabrasFrances.get(i) + " | Portugués: " + palabrasPortugues.get(i));
        }
        return todasLasPalabras;
    }
}