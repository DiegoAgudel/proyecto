package percistencia;



import logica.Diccionario;
import java.io.*;

public class GestorArchivo {

    private static final String ARCHIVO_DICCIONARIO = "diccionario.dat";  // Nombre del archivo

    // Método para cargar el diccionario desde un archivo
    public static void cargarDiccionario(Diccionario diccionario) throws IOException, ClassNotFoundException {
        File archivo = new File(ARCHIVO_DICCIONARIO);
        if (archivo.exists()) {
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(archivo))) {
                diccionario = (Diccionario) ois.readObject();  // Carga el diccionario
            }
        }
    }

    // Método para guardar el diccionario en un archivo
    public static void guardarDiccionario(Diccionario diccionario) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ARCHIVO_DICCIONARIO))) {
            oos.writeObject(diccionario);
        }
    }
}
